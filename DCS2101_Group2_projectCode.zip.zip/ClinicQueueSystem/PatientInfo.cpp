#include "PatientInfo.h"
#include <iostream>
#include <string>


using namespace std; 

//Constructor
PatientInfo::PatientInfo(){
	patientID = "";
	name = "";
	contact = "";
}

//Setters
string PatientInfo::setID(string a){
	patientID = a;
	return a;
}

string PatientInfo::setName(string b){
	name = b;
	return b;
}

string PatientInfo::setContact(string c){
	contact = c;
	return c;
}


//Getters 
string PatientInfo::getID(){
	return patientID;
}

string PatientInfo::getName(){
	return name;
}

string PatientInfo::getContact(){
	return contact;
}

//Extra Funtions
// User input new patient details
void PatientInfo::setPatientInfo(string a, string b, string c){
	patientID = a;
	name = b;
	contact = c; 
}

// Display new patient details for confirmation 
void PatientInfo::displayPatientInfo(){
	cout<<"******************************************************************************************************"<<endl;
	cout<<"That Patient's details are as below "<<endl<<endl;
	
	cout<<"Patient ID          : p" <<getID()<<endl;	
	cout<<"Patient Name        : " <<getName()<<endl;
	cout<<"Patient Contact No. : +60" <<getContact()<<endl;
	cout<<"******************************************************************************************************"<<endl;
}


