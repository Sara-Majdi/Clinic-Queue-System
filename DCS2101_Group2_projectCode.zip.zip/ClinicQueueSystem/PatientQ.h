#ifndef PATIENTQ_H
#define PATIENTQ_H
#include "PatientInfo.h"
#include <string>

using namespace std;



class PatientQ
{
	// Declarations of public member functions
	public:
		PatientQ();                              //Constructor to initialize the private attributes
		bool isEmpty();                          //To check whether the funtion is empty
		int size();                              //To check the number of Patients in the Queue, returns the total Patients in the Queue
		bool enqueue(PatientInfo new_patient);   //Add new Patients at the back of the Queue    
		bool dequeue(PatientInfo &patient);      //Removes the existing Patients from the front of the Queue
		bool getFront(PatientInfo &patient);     //Retrives the first Patient in the Queue
		bool displayAll();                       //Display all the Patients in the Queue
		
	private:
		//Declaration of QueueNode to store items in queue as Linked List
		struct QueueNode
		{ 
			PatientInfo newPatient;   //Attribute from the PatientInfo Class
			QueueNode *next;          //Pointer to the next QueueNode
		};
		
		//Attributes
		QueueNode *frontPtr; // Pointer to front of Queue
		QueueNode *backPtr;  // Pointer to back of Queue
		int length;          // The Length of the Queue
};

#endif
