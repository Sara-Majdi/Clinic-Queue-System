#ifndef PATIENTINFO_H
#define PATIENTINFO_H
#include <string>

using namespace std; 

class PatientInfo
{	
	// Declarations of public member functions
	public:
		//Constuctor
		PatientInfo();   //Inirialize all private attributes
		
		//Setters
		string setID(string a);        //Sets the Patient ID when User input new patient's ID
		string setName(string b);      //Sets the Patient Name when User input new patient's name
		string setContact(string c);   //Sets the Patient Contact when User input new patient's contact number
		
		//Getters
		string getID();        //Returns the Patient ID
		string getName();      //Returns the Patient Name
		string getContact();   //Returns the Patient Contact Number 
		
		//Extra Funtions
		void setPatientInfo(string a, string b, string c); // Sets the Patient Info when User input new patient details
		void displayPatientInfo(); // Display patient details for confirmation 
		
	private:
		//Attributes
		string patientID;  //Patient ID
		string name;       //Patient Name
		string contact;    //Patient Contact
};

#endif
