#include <iostream>
#include <iomanip>
#include <string>
#include "PatientQ.h"
#include "PatientInfo.h"
#include "PaymentList.h"
#include "Log.h"

using namespace std; 

void mainMenu();               //Prototype of mainMenu() funtion
void reportMenu();             //Prototype of reportMenu() funtion
void displayActivityMenu();    //Prototype of displayActivityMenu() funtion

int main() {
	
	//Declare and Initialize Variables
	PatientInfo patient;
	PatientQ queue;
	PaymentList pay;
	Log log;
	bool repeat = true, repeat2 = true, repeat3 = true;
	int choice, reportChoice, displayChoice, num;
	string patientID, name, contact;
	double price;
	
	//Do while loop
	do{
		mainMenu(); //Display Main Menu
		cout<<"Please Enter an Operation (1, 2, 3, 4, 5, 6)"<<endl;
		cin>>choice;
		
		system("pause");
		system("cls");
		
		switch(choice){
			
			//Case 1 : Add a new patient in the Queue after user inputs the patient details
			//         The details of the the new patient will be printed out just for confirmation
			case 1:{
				log.push("Add a New Patient in the Queue            ", true);
				
				cout<<"Patient ID (6 Digits) : p"; 
				cin>> patientID;
				patient.setID(patientID);
				cout<<"Patient Name          : "; 
				cin>> name;
				patient.setName(name);
				cout<<"Patient Contact No.   : +60";
				cin>> contact;
				patient.setContact(contact);
				cout<<endl<<endl<<endl;
				cout<<"New Patient is successfully Added in the Queue"<<endl<<endl<<endl;
				cout<<"New Patient Details : "<<endl;
				patient.displayPatientInfo(); 
				
				patient.setPatientInfo(patientID, name, contact);
				queue.enqueue(patient);
				
				system("pause");
				system("cls");
				break;
			}
			
			//Case 2 : User is able to look who is the first Patient in the Queue that is in the Doctor Room
			case 2:{		                  
				log.push("View Current Patient                      ", true);
				queue.getFront(patient);
				if (!queue.isEmpty()){
					cout << "The current patient in the Doctor's Room: "<<endl<<endl<<endl;
					patient.displayPatientInfo();
				}
				
				system("pause");
				system("cls");
				break;
			}
			
			//Case 3 : User is able to look at the number of patients that are in the Queue currently
			case 3:{
				log.push("View Total Patients currently in the Queue     ", true);
				cout<<"There are totally "<<queue.size()<<" Patients in the Queue now. "<<endl;
				
				system("pause");
				system("cls");
				break;
			}
			
			//Case 4 : The next patient in the Queue visits the Doctor after the previous patient's payment has been inserted by the user
			//         The details of the the new and previous patient will be printed out just for confirmation
			case 4:{
				log.push("Get Next Patient in the Queue             ", true);
				if (!queue.isEmpty()) {
					queue.dequeue(patient);
					cout << "A Patient is removed from the Queue."<<endl<<endl;;
					patient.displayPatientInfo(); 
					cout << "Please Enter the Payment Amount: RM ";
					cin>>price;
					pay.push(patient, price);
					cout<<endl<<endl<<endl;
					
					cout<<"Next Patient could visit the Doctor Room now. "<<endl<<endl;
					if (!queue.isEmpty()) {
						queue.getFront(patient);
						patient.displayPatientInfo();
					}
					
					else {
						cout << "There is no one in the queue yet.";
						cout << endl << endl;
					}
				}
				else {
					cout << "There is no one in the queue yet." << endl << endl;
				}
				system("pause");
				system("cls");
				break;
			}
			
			//Case 5 : Displays Summary Report Menu and asks for user's input choice
			case 5:{
				log.push("Generate Summary Report                   ", true);
				do{
					reportMenu();
					cout<<"Please Enter an Operation (1, 2, 3, 4, 5)"<<endl;
					cin>>reportChoice;
					system("pause");
					system("cls");
					switch(reportChoice){
						
						// Case 1 : User is able to look at all Patients in the Queue along with their details
						case 1: {
							log.push("View List of Patient in the Queue         ", true);
							cout<<"The List of Patients in the Queue : "<<endl<<endl;
							cout<<"The order is from the First Patient to the Last Patient in the Queue. "<<endl<<endl;
							queue.displayAll();
							system("pause");
							system("cls");
							repeat2 = true;
							break;
						}
						
						// Case 2 : User is able to look at all the payments that have been made by the patients that
						//          have visited the Doctor            
						case 2: {						
							log.push("View Payment List                         ", true);
							cout<<"The Payment List : "<<endl<<endl;
							cout<<"(Starting from the recent ones on top)"<<endl<<endl;
							pay.displayAll();
							cout << endl;
							system("pause");
							system("cls");
							break;
						}
						
						
						//Case 3 : Displays Activity Log Menu and asks for user's input choice
						case 3: {
							log.push("View Activity Log                         ", true);
							do{
								displayActivityMenu();
								cout<<"Please Enter an Operation (1, 2, 3)"<<endl;
								cin>>displayChoice;
	
								switch(displayChoice){
									
									//Case 1 : Displays the specific amount of activities in the Activity Log.
									//         Users should input the specifc amount 
									case 1:{
										log.push("Display certain number of Activities      ", true);
										system("cls");
										cout<<"Enter the number of activities : ";
										cin>>num;
										cout<<endl<<endl;
										log.displayN(num);
									
										system("pause");
										system("cls");
										break;
									}
									
									//Case 2 : Displays all of the activities in the Activity Log along with the 
									//         operation details and status
									case 2:{									
										log.push("Display all Activities                    ", true);
										system("cls");
										log.displayAll();
										system("pause");
										system("cls");
										break;
									}	
									
									// Case 3 : Returns to the Summary Report Menu screen
									case 3: {
										log.push("Back to previous screen                   ", true);
										repeat3 = false;
										system("cls");
										break;
									}
									
									// Case 4 : Returns to the Main Menu screen
									case 4: {
										log.push("Back to main menu                         ", true);
										repeat3 = false;
										repeat2 = false;
										system("cls");
										break;
									}
									
									//Case 5: User exits and leaves the system 
									case 5: {					
										log.push("Exit System                               ", true);
										cout<<"Thank you, have a great day."<<endl;
										exit(0);
										system("pause");
										system("cls");
										break;
									}
									
									// Default : When users enter ivnvalid inputs, it will prompt a message and returns to the 
									//           Summary Report Menu 
									default:
										log.push("Invalid Input                            ", false);
										cout<<"Invalid Input. Please Try Again. "<<endl;
										system("pause");
										system("cls");
										break;
								}
						}while(repeat3);
						
						break;
						}
						
						//Case 4 : Returns to the Main Menu 
						case 4: {
							log.push("Back to Main Menu                         ", true);
							repeat2 = false;
							break;
						}
						
						//Case 5: User exits and leaves the system 
						case 5: {					
							log.push("Exit System                               ", true);
							cout<<"Thank you, have a great day."<<endl;
							exit(0);
							system("pause");
							system("cls");
							break;
						}
						
						// Default : When users enter ivnvalid inputs, it will prompt a message and returns to the 
						//           Main Menu 
						default: {
							log.push("Invalid Input                            ", false);
							cout<<"Invalid Input. Please Try Again. "<<endl;
							system("pause");
							system("cls");
							break;
						}
					}
				}while(repeat2);
				break;
			}
			
			// Case 6 : User exits and leave the system 
			case 6:{
				log.push("Exit System                               ", true);
				cout<<"Thank you, have a great day."<<endl;
				exit(0);
				break;
			}
			
			// Default : When users enter ivnvalid inputs, it will prompt a message and returns to the 
			//           Main Menu 
			default: {
				log.push("Invalid Input                             ", false);
				cout<<"Invalid Input. Please Try Again. "<<endl;
				system("pause");
				system("cls");
				break;
			}
		}
	}while(repeat);

	return 0;
}

//Declaration of Funtion that Displays Main Menu 
void mainMenu(){
	cout<<"****************************************************"<<endl ;
	cout<<"     Welcome to the SM Clinic Queueing System "<<endl ;
	cout<<"****************************************************"<<endl ;
	cout<<"No."<<setw(20)<<"Menu"<<endl ;
	cout<<"****************************************************"<<endl ;
	cout<<"1.   Add a New Patient in the Queue"<<endl ;
	cout<<"2.   View Current Patient"<<endl ;
	cout<<"3.   View Total Patients currently in the Queue"<<endl ;
	cout<<"4.   Get Next Patient in the Queue"<<endl ;
	cout<<"5.   Generate Summary Report"<<endl ;
	cout<<"6.   Exit System"<<endl ;
	cout<<"****************************************************"<<endl ;
}

//Declaration of Funtion that Displays Summary Report Menu
void reportMenu(){
	cout<<"********************************************"<<endl ;
	cout<<"No."<<setw(20)<<"Menu"<<endl ;
	cout<<"********************************************"<<endl ;
	cout<<"1.   View List of Patient in the Queue"<<endl ;
	cout<<"2.   View Payment List"<<endl ;
	cout<<"3.   View Activity Log"<<endl ;
	cout<<"4.   Back to Main Menu"<<endl ;
	cout<<"5.   Exit System"<<endl ;
	cout<<"********************************************"<<endl ;
}

//Declaration of Funtion that Displays Activity Log Menu
void displayActivityMenu(){
	cout<<"********************************************"<<endl ;
	cout<<"No."<<setw(20)<<"Menu"<<endl ;
	cout<<"********************************************"<<endl ;
	cout<<"1.   Display certain number of Activities"<<endl ;
	cout<<"2.   Display all Activities"<<endl ;
	cout<<"3.   Back to Previous Screen"<<endl ;
	cout<<"4.   Back to Main Menu"<<endl ;
	cout<<"5.   Exit System "<<endl ;
	cout<<"********************************************"<<endl ;	
}
