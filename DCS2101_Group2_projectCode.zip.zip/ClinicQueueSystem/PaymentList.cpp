#include "PaymentList.h"
#include "PatientInfo.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

// Default constructor, which creates a new empty
// Stack, initializing topPtr to NULL
PaymentList::PaymentList(){
	topPtr = NULL;
}

// Returns true if Stack is empty, otherwise returns false
bool PaymentList::isEmpty(){
	if (topPtr == NULL) 
		return true;
	
	else
	return false;
}

// Adds new payment at the back of the Stack. 
// Returns true if push succeeds, otherwise returns false.
bool PaymentList::push(PatientInfo new_patient, double payment2) {
	StackNode *p = new StackNode;
	if (p == NULL)
		return false;
	
	p->newPatient = new_patient;
	p->price = payment2;
	p->next = topPtr;
	topPtr = p;
	return true;
}

// Display all payment that have been paid in the Stack
bool PaymentList::displayAll() {
	
	if (isEmpty()){
		cout<<"There is not any payment made ";
		return false;
	}
	
	StackNode *currPtr = topPtr;
	
	cout<<"****************************************************************"<<endl ;
	cout<<setw(35)<<"Patient Payment Details"<<endl ;
	cout<<"****************************************************************"<<endl ;
	cout<<setw(8)<<"ID"<<setw(19)<<"Name"<<setw(27)<<"Payment (RM) "<<endl ;	
	cout<<"****************************************************************"<<endl ;
	
	while (currPtr != NULL){
		cout<<setw(10)<<currPtr->newPatient.getID()<<setw(19)<<currPtr->newPatient.getName()<<setw(20)<<currPtr->price<<endl ;
		payment += currPtr->price;
		currPtr = currPtr -> next;
	}
	cout << endl;
	cout<<setw(30)<<"Total (RM)"<<setw(19)<<payment<<endl;
	return true;
}

