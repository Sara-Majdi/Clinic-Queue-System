#include "PatientQ.h"
#include "PatientInfo.h"
#include <iostream>
#include <string>

using namespace std; 

// Default constructor, which creates a new empty
// Queue, initializing frontPtr & backPtr to NULL
PatientQ::PatientQ()
{
	frontPtr = NULL;
	backPtr = NULL;
	length = 0;
}

// Returns true if Queue is empty, otherwise returns false
bool PatientQ::isEmpty( )
{
	if (length == 0)
		return true;
	else
		return false;
}

// Returns the length of the Queue.
int PatientQ::size(){
	return length; 
}

// Adds new patient at the back of the Queue. 
// Returns true if enqueue succeeds, otherwise returns false.
bool PatientQ::enqueue(PatientInfo new_patient){
	QueueNode *p = new QueueNode;
	if(p==NULL)
		return false;
		
	p->newPatient.setPatientInfo(new_patient.getID(), new_patient.getName(), new_patient.getContact());
	p->next = NULL;
	
	if (isEmpty( )) {
		frontPtr = p;
		backPtr = p;
	}
	else {
		backPtr->next = p;
		backPtr = p;
	}
	
	length++;
	return true;		
}

// Removes the patient at the front of a Queue and returns it in "patient". 
// Returns true if succeeds, otherwise returns false.
bool PatientQ::dequeue(PatientInfo &patient){

	if (isEmpty( )) {
		cout<<"There are no patients currenty in the Queue. "<<endl;
		return false;
	}
		
	QueueNode *p = frontPtr;
	patient.setPatientInfo(frontPtr->newPatient.getID(), frontPtr->newPatient.getName(), frontPtr->newPatient.getContact());
	
	if (frontPtr == backPtr) {
		frontPtr = NULL;
		backPtr = NULL;
	}
	else{
		frontPtr = frontPtr->next;
	}
	
	length--;	
	delete p;
	return true;
}

// Retrieves a copy of the new_patient at the front of a Queue and returns it in "patient", leaving the Queue unchanged.
// Returns true if succeeds, otherwise returns false.
bool PatientQ::getFront(PatientInfo &patient){
	if (isEmpty( )) {
		cout<<"There are no patients currenty in the Queue. "<<endl;
		return false;
	}
	
	patient = frontPtr->newPatient;
	return true;	
}

// Display all the patients that are currently in the Queue
bool PatientQ::displayAll(){
	if (isEmpty( )){
		cout<<"There are no patients currenty in the Queue. "<<endl;
		return false;
	}
	
	QueueNode *currPtr;
	currPtr = frontPtr;
	
	while (currPtr != NULL){
		cout<<"******************************************************************************************************"<<endl;
		cout<< "Patient ID            : p" <<currPtr->newPatient.getID()<<endl; 
		cout<< "Patient Name          : " <<currPtr->newPatient.getName()<<endl;
		cout<< "Patient Contact No.   : +60" <<currPtr->newPatient.getContact()<<endl;
   		currPtr = currPtr->next;
	}
	cout<<"******************************************************************************************************"<<endl;
	return true;
}
