#include "Log.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Default constructor, which creates a new empty
// Stack, initializing topPtr to NULL
Log::Log(){
	topPtr = NULL;
	numOfItem = 0;
}

// Returns true if Stack is empty, otherwise returns false
bool Log::isEmpty(){
	if(topPtr==NULL)
		return true;
	
	else
		return false;
}

// Adds new activity at the back of the Stack. 
// Returns true if push succeeds, otherwise returns false.
bool Log::push(string a, bool s){
	StackNode *p = new StackNode;
	if (p == NULL)
		return false;
	
	p->activity = a;
	p->successful = s;
	p->next = topPtr;
	topPtr = p;
	numOfItem++;
	return true;
}

// Display certain number of activities that have been made in the Stack
bool Log::displayN(int n){
	StackNode *currPtr = topPtr;
	string activityStatus;
	
	cout<<"****************************************************************************************************************"<<endl;
	cout<< setw(42) << "Activities Log" <<endl;
	cout<<"****************************************************************************************************************"<<endl;
	cout<< setw(6) << "No." << setw(32) << "Operations" << setw(32) << "Status"<<endl;
	cout<<"****************************************************************************************************************"<<endl;
	
	
	if (isEmpty()){
		cout << "The Activity Log is empty. ";
		return false;
	}
	
	for (int i=0; i<n; i++){
			if (currPtr == NULL || i == numOfItem) {
				cout << endl;
				cout << "You've reached the oldest log activity." << endl;
				cout << "Total Log Activity: " << i << endl << endl;
				
				break;
			}
			else {
				if (currPtr->successful){
					activityStatus = "Succesful";
				}
				else {
					activityStatus = "Fail";
				}
				cout<< setw(4) << i+1 << setw(59) << currPtr->activity <<activityStatus<< endl;
			}
			currPtr = currPtr->next;
		}
}

// Display all the activities that have been made in the Stack
bool Log::displayAll(){
	StackNode *currPtr = topPtr;
	string activityStatus;
	int num = 1;
	cout<<"****************************************************************************************************************"<<endl;
	cout<< setw(42) << "Activities Log" <<endl;
	cout<<"****************************************************************************************************************"<<endl;
	cout<< setw(6) << "No." << setw(32) << "Operations" << setw(32) << "Status"<<endl;
	cout<<"****************************************************************************************************************"<<endl;
	
	if (isEmpty()){
		cout << "The Activity Log is empty. ";
		return false;
	}
	
	else{
		while (currPtr != NULL){
			if (currPtr->successful){
				activityStatus = "Succesful";
			}
			else {
				activityStatus = "Fail";
			}
			cout<< setw(4) << num << setw(59) << currPtr->activity <<activityStatus<< endl;
			num++;
			currPtr = currPtr->next;
		}
	}
	
}
