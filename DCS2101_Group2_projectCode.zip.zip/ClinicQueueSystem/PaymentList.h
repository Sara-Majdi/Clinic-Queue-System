#ifndef PAYMENTLIST_H
#define PAYMENTLIST_H
#include "PatientInfo.h"
#include <string>

using namespace std;

class PaymentList{
	// Declarations of public member functions
	public:
		PaymentList();                                         //Constructor to initialize the topPtr
		bool isEmpty();                                        //Checks whether the funtion is empty
		bool push(PatientInfo new_patient, double payment2);   //Adds new payment in the PaymentList Stack
		bool displayAll();                                     //Displays all the payments that have been made 
		
	
	private:
		// Linked Lists of patients in Stack
		struct StackNode{
			PatientInfo newPatient;   //The attribute from the PatientInfo Class
			double price;             //The amount to be paid by one Patient
			StackNode *next;          //Pointer to the next StackNode
		};
		
		// Other Attributes
		StackNode *topPtr; // Pointer to the top of Stack
		double payment; // The total amount paid by all the Patients in the Queue
};

#endif
