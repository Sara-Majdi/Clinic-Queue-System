#ifndef LOG_H
#define LOG_H
#include <string>

using namespace std;


class Log{
	// Declarations of public member functions	
	public:
		Log();                                  //Constructor to initialize the private attributes
		bool isEmpty();                         //Checks whether the funtion is empty
		bool push(string a, bool s);            //Adds new activity in the Log stack
		bool displayN(int n);                   //Diplays certain number of Activities in the Stack 
		bool displayAll();                      //Diplay all the Activities in the Stack
		
	private:
		// Linked Lists of activities in Stack
		struct StackNode{             
			string activity;   //Stores the details of the Activity
			bool successful;   //Checks whether the activity is successfully carried out or not  
			StackNode *next;   //Pointer to the next StackNode
		};
		
		// Other Attributes
		StackNode *topPtr; //Pointer to top of the Queue
		int numOfItem;	   //Tracks the size of the Stack
};

#endif
